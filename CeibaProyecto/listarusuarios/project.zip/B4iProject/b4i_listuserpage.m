
#import "b4i_listuserpage.h"
#import "b4i_main.h"
#import "b4i_postsuserpage.h"
#import "b4i_httputils2service.h"
#import "b4i_httpjob.h"

@interface ResumableSub_listuserpage_ConsultarPost :B4IResumableSub 
- (instancetype) init: (b4i_listuserpage*) parent1 :(NSString*) _url1;
@end
@implementation ResumableSub_listuserpage_ConsultarPost {
b4i_listuserpage* parent;
NSString* _url;
b4i_httpjob* _j;
}
- (instancetype) init: (b4i_listuserpage*) parent1 :(NSString*) _url1 {
self->_url = _url1;
self->parent = parent1;
return self;
}
- (void) resume:(B4I*)bi1 :(NSArray*)result {
self.bi = bi1;

    while (true) {
        switch (self->_state) {
            case -1:
{
[parent->___c ReturnFromResumableSub:self :nil];return;}
case 0:
//C
self->_state = 1;
 //BA.debugLineNum = 95;BA.debugLine="Dim j As HttpJob";
self->_j = [b4i_httpjob new];
 //BA.debugLineNum = 96;BA.debugLine="j.Initialize(\"\", Me)";
[self->_j _initialize /*NSString**/ :self.bi :@"" :parent];
 //BA.debugLineNum = 97;BA.debugLine="j.Download(Url)";
[self->_j _download /*NSString**/ :self->_url];
 //BA.debugLineNum = 98;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
[parent->___c WaitFor:@"jobdone:" :self.bi :self :(NSObject*)(self->_j)];
self->_state = 7;
return;
case 7:
//C
self->_state = 1;
self->_j = ((b4i_httpjob*) result[0]);
;
 //BA.debugLineNum = 99;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
self->_state = 6;
if (self->_j->__success /*BOOL*/ ) { 
self->_state = 3;
}else {
self->_state = 5;
}if (true) break;

case 3:
//C
self->_state = 6;
 //BA.debugLineNum = 100;BA.debugLine="Main.stringPosts = j.GetString";
parent->__main->__stringposts /*NSString**/  = [self->_j _getstring /*NSString**/ ];
 if (true) break;

case 5:
//C
self->_state = 6;
 //BA.debugLineNum = 102;BA.debugLine="Log(\"ERROR: \" & j.ErrorMessage)";
[parent->___c LogImpl:@"79633800" :[@[@"ERROR: ",self->_j->__errormessage /*NSString**/ ] componentsJoinedByString:@""] :0];
 if (true) break;

case 6:
//C
self->_state = -1;
;
 //BA.debugLineNum = 104;BA.debugLine="j.Release";
[self->_j _release /*NSString**/ ];
 //BA.debugLineNum = 105;BA.debugLine="Return j.Success";
if (true) {
[parent->___c ReturnFromResumableSub:self :(NSObject*)(@(self->_j->__success /*BOOL*/ ))];return;};
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
@end
@interface ResumableSub_listuserpage_JHRListView1_ItemClick :B4IResumableSub 
- (instancetype) init: (b4i_listuserpage*) parent1 :(int) _index1 :(NSObject*) _value1;
@end
@implementation ResumableSub_listuserpage_JHRListView1_ItemClick {
b4i_listuserpage* parent;
int _index;
NSObject* _value;
BOOL _success;
}
- (instancetype) init: (b4i_listuserpage*) parent1 :(int) _index1 :(NSObject*) _value1 {
self->_index = _index1;
self->_value = _value1;
self->parent = parent1;
return self;
}
- (void) resume:(B4I*)bi1 :(NSArray*)result {
self.bi = bi1;

    while (true) {
        switch (self->_state) {
            case -1:
return;

case 0:
//C
self->_state = 1;
 //BA.debugLineNum = 86;BA.debugLine="Main.valueObject = Value";
parent->__main->__valueobject /*NSObject**/  = self->_value;
 //BA.debugLineNum = 87;BA.debugLine="Wait For (ConsultarPost($\"https://jsonplaceholder";
[parent->___c WaitFor:@"complete:" :self.bi :self :[parent _consultarpost:([@[@"https://jsonplaceholder.typicode.com/posts?userId=",[parent->___c SmartStringFormatter:@"" :(NSObject*)(@(((_datauser*)(self->_value))->_ID /*int*/ ))],@""] componentsJoinedByString:@""])]];
self->_state = 5;
return;
case 5:
//C
self->_state = 1;
self->_success = ((NSNumber*) result[0]).boolValue;
;
 //BA.debugLineNum = 88;BA.debugLine="If Success Then";
if (true) break;

case 1:
//if
self->_state = 4;
if (self->_success) { 
self->_state = 3;
}if (true) break;

case 3:
//C
self->_state = 4;
 //BA.debugLineNum = 89;BA.debugLine="Log(\"Consulta de posts exitosa!\")";
[parent->___c LogImpl:@"78585220" :@"Consulta de posts exitosa!" :0];
 //BA.debugLineNum = 90;BA.debugLine="postsUserPage.Show";
[parent->__postsuserpage _show /*NSString**/ ];
 if (true) break;

case 4:
//C
self->_state = -1;
;
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
@end
@implementation _datauser
-(void)Initialize{
self.IsInitialized = true;
self->_nameUser = @"";
self->_emailUser = @"";
self->_phoneUser = @"";
self->_ID = 0;
self->_imageFile = @"";
}
- (NSString*)description {
return [B4I TypeToString:self :false];}
@end

@implementation b4i_listuserpage 


+ (instancetype)new {
    static b4i_listuserpage* shared = nil;
    if (shared == nil) {
        shared = [self alloc];
        shared.bi = [[B4I alloc] init:shared];
        shared.__c = [B4ICommon new];
    }
    return shared;
}

- (NSString*)  _addviewtokeyboard:(B4ITextFieldWrapper*) _textfield1 :(B4IViewWrapper*) _view1{
B4INativeObject* _no = nil;
 //BA.debugLineNum = 108;BA.debugLine="Sub AddViewToKeyboard(TextField1 As TextField, Vie";
 //BA.debugLineNum = 109;BA.debugLine="Dim no As NativeObject = TextField1";
_no = [B4INativeObject new];
_no = (B4INativeObject*) [B4IObjectWrapper createWrapper:[B4INativeObject new] object:(NSObject*)((_textfield1).object)];
 //BA.debugLineNum = 110;BA.debugLine="no.SetField(\"inputAccessoryView\", View1)";
[_no SetField:@"inputAccessoryView" :(NSObject*)((_view1).object)];
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _btndone_click{
 //BA.debugLineNum = 113;BA.debugLine="Sub btnDone_Click";
 //BA.debugLineNum = 114;BA.debugLine="Page.ResignFocus";
[self->__page ResignFocus];
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _consultarlistausuario:(NSString*) _querytype{
B4IList* _listbitmap = nil;
B4IResultSet* _rs = nil;
_datauser* _data = nil;
B4IPanelWrapper* _p = nil;
 //BA.debugLineNum = 34;BA.debugLine="Private Sub consultarListaUsuario(queryType As Str";
 //BA.debugLineNum = 35;BA.debugLine="JHRListView1.Clear";
[self->__jhrlistview1 _clear];
 //BA.debugLineNum = 36;BA.debugLine="Dim listBitmap As List = Array(\"img1.png\",\"img2.p";
_listbitmap = [B4IList new];
_listbitmap = [self.bi ArrayToList:[[B4IArray alloc]initObjectsWithData:@[[B4I nilToNSNull:(NSObject*)(@"img1.png")],[B4I nilToNSNull:(NSObject*)(@"img2.png")],[B4I nilToNSNull:(NSObject*)(@"img3.png")],[B4I nilToNSNull:(NSObject*)(@"img4.png")],[B4I nilToNSNull:(NSObject*)(@"img5.png")]]]];
 //BA.debugLineNum = 37;BA.debugLine="Dim rs As ResultSet = SQL1.ExecQuery(queryType)";
_rs = [self->__sql1 ExecQuery:_querytype];
 //BA.debugLineNum = 38;BA.debugLine="Do While rs.NextRow";
while ([_rs NextRow]) {
 //BA.debugLineNum = 39;BA.debugLine="Dim data As dataUser";
_data = [_datauser new];
 //BA.debugLineNum = 40;BA.debugLine="data.Initialize";
[_data Initialize];
 //BA.debugLineNum = 41;BA.debugLine="data.nameUser = rs.GetString(\"Nombres\")";
_data->_nameUser /*NSString**/  = [_rs GetString:@"Nombres"];
 //BA.debugLineNum = 42;BA.debugLine="data.phoneUser = rs.GetString(\"Telefono\")";
_data->_phoneUser /*NSString**/  = [_rs GetString:@"Telefono"];
 //BA.debugLineNum = 43;BA.debugLine="data.emailUser = rs.GetString(\"Email\")";
_data->_emailUser /*NSString**/  = [_rs GetString:@"Email"];
 //BA.debugLineNum = 44;BA.debugLine="data.ID = rs.GetInt(\"ID_User\")";
_data->_ID /*int*/  = [_rs GetInt:@"ID_User"];
 //BA.debugLineNum = 45;BA.debugLine="data.imageFile = listBitmap.Get((rs.GetInt(\"ID\")";
_data->_imageFile /*NSString**/  = [self.bi ObjectToString:[_listbitmap Get:(int) (([_rs GetInt:@"ID"]-1)%[_listbitmap Size])]];
 //BA.debugLineNum = 46;BA.debugLine="Dim p As Panel = xui.CreatePanel(\"\")";
_p = [B4IPanelWrapper new];
_p = (B4IPanelWrapper*) [B4IObjectWrapper createWrapper:[B4IPanelWrapper new] object:(B4IPanelView*)(([self->__xui CreatePanel:self.bi :@""]).object)];
 //BA.debugLineNum = 47;BA.debugLine="p.SetLayoutAnimated(0,1, 0, 0, JHRListView1.AsVi";
[_p SetLayoutAnimated:(int) (0) :(float) (1) :(float) (0) :(float) (0) :[[self->__jhrlistview1 _asview] Width] :(float) (((int) (150)))];
 //BA.debugLineNum = 48;BA.debugLine="JHRListView1.Add(p, data)";
[self->__jhrlistview1 _add:(B4XViewWrapper*) [B4IObjectWrapper createWrapper:[B4XViewWrapper new] object:(NSObject*)((_p).object)] :(NSObject*)(_data)];
 }
;
 //BA.debugLineNum = 50;BA.debugLine="If JHRListView1.Size = 0 Then";
if ([self->__jhrlistview1 _getsize]==0) { 
 //BA.debugLineNum = 51;BA.debugLine="imgEmptyList.As(B4XView).Visible = True";
[((B4XViewWrapper*) [B4IObjectWrapper createWrapper:[B4XViewWrapper new] object:(NSObject*)((self->__imgemptylist).object)]) setVisible:true];
 }else {
 //BA.debugLineNum = 53;BA.debugLine="imgEmptyList.As(B4XView).Visible = False";
[((B4XViewWrapper*) [B4IObjectWrapper createWrapper:[B4XViewWrapper new] object:(NSObject*)((self->__imgemptylist).object)]) setVisible:false];
 };
 //BA.debugLineNum = 55;BA.debugLine="ProgressWait.Visible = False";
[self->__progresswait setVisible:false];
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return @"";
}
- (B4IResumableSubWrapper*)  _consultarpost:(NSString*) _url{
ResumableSub_listuserpage_ConsultarPost* rsub = [[ResumableSub_listuserpage_ConsultarPost alloc] init:self : _url];
[rsub resume:self.bi :nil];
return (B4IResumableSubWrapper*) [B4IObjectWrapper createWrapper:[B4IResumableSubWrapper new] object:rsub];
}
//-744542705
- (void)  _jobdone:(b4i_httpjob*) _j{
}
- (NSString*)  _edtbuscador_textchanged:(NSString*) _oldtext :(NSString*) _newtext{
 //BA.debugLineNum = 57;BA.debugLine="Private Sub edtBuscador_TextChanged (OldText As St";
 //BA.debugLineNum = 58;BA.debugLine="consultarListaUsuario($\"SELECT * FROM Usuarios WH";
[self _consultarlistausuario:([@[@"SELECT * FROM Usuarios WHERE Nombres LIKE '%",[self->___c SmartStringFormatter:@"" :(NSObject*)(_newtext)],@"%'"] componentsJoinedByString:@""])];
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return @"";
}
- (void)  _jhrlistview1_itemclick:(int) _index :(NSObject*) _value{
ResumableSub_listuserpage_JHRListView1_ItemClick* rsub = [[ResumableSub_listuserpage_JHRListView1_ItemClick alloc] init:self : _index: _value];
[rsub resume:self.bi :nil];
}
//-1106064916
- (void)  _complete:(BOOL) _success{
}
- (NSString*)  _jhrlistview1_visiblerangechanged:(int) _firstindex :(int) _lastindex{
int _extrasize = 0;
int _i = 0;
B4IPanelWrapper* _p = nil;
_datauser* _du = nil;
 //BA.debugLineNum = 61;BA.debugLine="Private Sub JHRListView1_VisibleRangeChanged (Firs";
 //BA.debugLineNum = 62;BA.debugLine="Dim ExtraSize As Int = 20";
_extrasize = (int) (20);
 //BA.debugLineNum = 63;BA.debugLine="For i = 0 To JHRListView1.Size - 1";
{
const int step2 = 1;
const int limit2 = (int) ([self->__jhrlistview1 _getsize]-1);
_i = (int) (0) ;
for (;_i <= limit2 ;_i = _i + step2 ) {
 //BA.debugLineNum = 64;BA.debugLine="Dim p As Panel = JHRListView1.GetPanel(i)";
_p = [B4IPanelWrapper new];
_p = (B4IPanelWrapper*) [B4IObjectWrapper createWrapper:[B4IPanelWrapper new] object:(B4IPanelView*)(([self->__jhrlistview1 _getpanel:_i]).object)];
 //BA.debugLineNum = 65;BA.debugLine="If i > FirstIndex - ExtraSize And i < LastIndex";
if (_i>_firstindex-_extrasize && _i<_lastindex+_extrasize) { 
 //BA.debugLineNum = 67;BA.debugLine="If p.NumberOfViews = 0 Then";
if ([_p NumberOfViews]==0) { 
 //BA.debugLineNum = 68;BA.debugLine="Dim du As dataUser = JHRListView1.GetValue(i)";
_du = (_datauser*)([self->__jhrlistview1 _getvalue:_i]);
 //BA.debugLineNum = 69;BA.debugLine="p.LoadLayout(\"CardUser\")";
[_p LoadLayout:@"CardUser" :self.bi];
 //BA.debugLineNum = 70;BA.debugLine="lblNameUserCard.Text = du.nameUser";
[self->__lblnameusercard setText:_du->_nameUser /*NSString**/ ];
 //BA.debugLineNum = 71;BA.debugLine="lblEmailUser.Text = du.emailUser";
[self->__lblemailuser setText:_du->_emailUser /*NSString**/ ];
 //BA.debugLineNum = 72;BA.debugLine="lblPhoneUser.Text = du.phoneUser";
[self->__lblphoneuser setText:_du->_phoneUser /*NSString**/ ];
 //BA.debugLineNum = 73;BA.debugLine="lblIdUser.Text = \"#\" & du.ID";
[self->__lbliduser setText:[@[@"#",[self.bi NumberToString:@(_du->_ID /*int*/ )]] componentsJoinedByString:@""]];
 //BA.debugLineNum = 74;BA.debugLine="imgUser.Bitmap = LoadBitmap(File.DirAssets,du.";
[self->__imguser setBitmap:[self->___c LoadBitmap:[[self->___c File] DirAssets] :_du->_imageFile /*NSString**/ ]];
 };
 }else {
 //BA.debugLineNum = 78;BA.debugLine="If p.NumberOfViews > 0 Then";
if ([_p NumberOfViews]>0) { 
 //BA.debugLineNum = 79;BA.debugLine="p.RemoveAllViews";
[_p RemoveAllViews];
 };
 };
 }
};
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _process_globals{
self->__main=[b4i_main new];
self->__postsuserpage=[b4i_postsuserpage new];
self->__httputils2service=[b4i_httputils2service new];
 //BA.debugLineNum = 1;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Page As Page";
self->__page = [B4IPage new];
 //BA.debugLineNum = 3;BA.debugLine="Private pnlBuscador As Panel";
self->__pnlbuscador = [B4IPanelWrapper new];
 //BA.debugLineNum = 4;BA.debugLine="Private edtBuscador As TextField";
self->__edtbuscador = [B4ITextFieldWrapper new];
 //BA.debugLineNum = 5;BA.debugLine="Private JHRListView1 As JHRListView";
self->__jhrlistview1 = [b4i_jhrlistview new];
 //BA.debugLineNum = 6;BA.debugLine="Private xui As XUI";
self->__xui = [B4IXUI new];
 //BA.debugLineNum = 7;BA.debugLine="Type dataUser(nameUser As String, emailUser As St";
;
 //BA.debugLineNum = 8;BA.debugLine="Private lblNameUserCard As Label";
self->__lblnameusercard = [B4ILabelWrapper new];
 //BA.debugLineNum = 9;BA.debugLine="Private lblIdUser As Label";
self->__lbliduser = [B4ILabelWrapper new];
 //BA.debugLineNum = 10;BA.debugLine="Private lblPhoneUser As Label";
self->__lblphoneuser = [B4ILabelWrapper new];
 //BA.debugLineNum = 11;BA.debugLine="Private lblEmailUser As Label";
self->__lblemailuser = [B4ILabelWrapper new];
 //BA.debugLineNum = 12;BA.debugLine="Private imgUser As ImageView";
self->__imguser = [B4IImageViewWrapper new];
 //BA.debugLineNum = 13;BA.debugLine="Private ProgressWait As ProgressView";
self->__progresswait = [B4IProgressWrapper new];
 //BA.debugLineNum = 14;BA.debugLine="Private SQL1 As SQL";
self->__sql1 = [B4ISQL new];
 //BA.debugLineNum = 15;BA.debugLine="Private imgEmptyList As ImageView";
self->__imgemptylist = [B4IImageViewWrapper new];
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _show{
B4IPanelWrapper* _pdone = nil;
 //BA.debugLineNum = 18;BA.debugLine="Public Sub Show";
 //BA.debugLineNum = 19;BA.debugLine="If Page.IsInitialized = False Then Page.Initializ";
if ([self->__page IsInitialized]==false) { 
[self->__page Initialize:self.bi :@"Page"];};
 //BA.debugLineNum = 20;BA.debugLine="Main.NavControl.ShowPage (Page)";
[self->__main->__navcontrol /*B4INavigationControllerWrapper**/  ShowPage:(UIViewController*)((self->__page).object)];
 //BA.debugLineNum = 21;BA.debugLine="Page.RootPanel.RemoveAllViews";
[[self->__page RootPanel] RemoveAllViews];
 //BA.debugLineNum = 22;BA.debugLine="Page.RootPanel.LoadLayout (\"Page2\")";
[[self->__page RootPanel] LoadLayout:@"Page2" :self.bi];
 //BA.debugLineNum = 23;BA.debugLine="Dim pDone As Panel";
_pdone = [B4IPanelWrapper new];
 //BA.debugLineNum = 24;BA.debugLine="pDone.Initialize(\"\")";
[_pdone Initialize:self.bi :@""];
 //BA.debugLineNum = 25;BA.debugLine="pDone.LoadLayout(\"keyBoardDone\")";
[_pdone LoadLayout:@"keyBoardDone" :self.bi];
 //BA.debugLineNum = 26;BA.debugLine="pDone.Height = 46";
[_pdone setHeight:(float) (46)];
 //BA.debugLineNum = 27;BA.debugLine="AddViewToKeyboard(edtBuscador, pDone)";
[self _addviewtokeyboard:self->__edtbuscador :(B4IViewWrapper*) [B4IObjectWrapper createWrapper:[B4IViewWrapper new] object:(UIView*)((_pdone).object)]];
 //BA.debugLineNum = 28;BA.debugLine="JHRListView1.Clear";
[self->__jhrlistview1 _clear];
 //BA.debugLineNum = 29;BA.debugLine="ProgressWait.Visible = True";
[self->__progresswait setVisible:true];
 //BA.debugLineNum = 30;BA.debugLine="SQL1.Initialize(File.DirDocuments,\"database.db\",F";
[self->__sql1 Initialize:[[self->___c File] DirDocuments] :@"database.db" :false];
 //BA.debugLineNum = 31;BA.debugLine="consultarListaUsuario(\"SELECT * FROM Usuarios\")";
[self _consultarlistausuario:@"SELECT * FROM Usuarios"];
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return @"";
}
@end
