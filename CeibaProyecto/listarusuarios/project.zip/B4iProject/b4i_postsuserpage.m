
#import "b4i_postsuserpage.h"
#import "b4i_main.h"
#import "b4i_listuserpage.h"
#import "b4i_httputils2service.h"
#import "b4i_httpjob.h"

@implementation _dataposts
-(void)Initialize{
self.IsInitialized = true;
self->_titlePosts = @"";
self->_bodyPost = @"";
self->_userIdPosts = 0;
}
- (NSString*)description {
return [B4I TypeToString:self :false];}
@end

@implementation b4i_postsuserpage 


+ (instancetype)new {
    static b4i_postsuserpage* shared = nil;
    if (shared == nil) {
        shared = [self alloc];
        shared.bi = [[B4I alloc] init:shared];
        shared.__c = [B4ICommon new];
    }
    return shared;
}

- (NSString*)  _btnatras_click{
 //BA.debugLineNum = 69;BA.debugLine="Private Sub btnAtras_Click";
 //BA.debugLineNum = 70;BA.debugLine="listUserPage.Show";
[self->__listuserpage _show /*NSString**/ ];
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _jhrlistviewposts_visiblerangechanged:(int) _firstindex :(int) _lastindex{
int _extrasize = 0;
int _i = 0;
B4IPanelWrapper* _p = nil;
_dataposts* _dp = nil;
 //BA.debugLineNum = 47;BA.debugLine="Private Sub JHRListViewPosts_VisibleRangeChanged (";
 //BA.debugLineNum = 48;BA.debugLine="Dim ExtraSize As Int = 20";
_extrasize = (int) (20);
 //BA.debugLineNum = 49;BA.debugLine="For i = 0 To JHRListViewPosts.Size - 1";
{
const int step2 = 1;
const int limit2 = (int) ([self->__jhrlistviewposts _getsize]-1);
_i = (int) (0) ;
for (;_i <= limit2 ;_i = _i + step2 ) {
 //BA.debugLineNum = 50;BA.debugLine="Dim p As Panel = JHRListViewPosts.GetPanel(i)";
_p = [B4IPanelWrapper new];
_p = (B4IPanelWrapper*) [B4IObjectWrapper createWrapper:[B4IPanelWrapper new] object:(B4IPanelView*)(([self->__jhrlistviewposts _getpanel:_i]).object)];
 //BA.debugLineNum = 51;BA.debugLine="If i > FirstIndex - ExtraSize And i < LastIndex";
if (_i>_firstindex-_extrasize && _i<_lastindex+_extrasize) { 
 //BA.debugLineNum = 53;BA.debugLine="If p.NumberOfViews = 0 Then";
if ([_p NumberOfViews]==0) { 
 //BA.debugLineNum = 54;BA.debugLine="Dim dp As dataPosts = JHRListViewPosts.GetValu";
_dp = (_dataposts*)([self->__jhrlistviewposts _getvalue:_i]);
 //BA.debugLineNum = 55;BA.debugLine="p.LoadLayout(\"listPosts\")";
[_p LoadLayout:@"listPosts" :self.bi];
 //BA.debugLineNum = 56;BA.debugLine="lblTittlePost.Text = dp.titlePosts";
[self->__lbltittlepost setText:_dp->_titlePosts /*NSString**/ ];
 //BA.debugLineNum = 57;BA.debugLine="lblBodyPosts.Text = dp.bodyPost";
[self->__lblbodyposts setText:_dp->_bodyPost /*NSString**/ ];
 //BA.debugLineNum = 58;BA.debugLine="lblIDPosts.Text = \"#\" & dp.userIdPosts";
[self->__lblidposts setText:[@[@"#",[self.bi NumberToString:@(_dp->_userIdPosts /*int*/ )]] componentsJoinedByString:@""]];
 };
 }else {
 //BA.debugLineNum = 62;BA.debugLine="If p.NumberOfViews > 0 Then";
if ([_p NumberOfViews]>0) { 
 //BA.debugLineNum = 63;BA.debugLine="p.RemoveAllViews";
[_p RemoveAllViews];
 };
 };
 }
};
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _page_resize:(int) _width :(int) _height{
 //BA.debugLineNum = 43;BA.debugLine="Private Sub Page_Resize(Width As Int, Height As In";
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _process_globals{
self->__main=[b4i_main new];
self->__listuserpage=[b4i_listuserpage new];
self->__httputils2service=[b4i_httputils2service new];
 //BA.debugLineNum = 3;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private xui As XUI";
self->__xui = [B4IXUI new];
 //BA.debugLineNum = 5;BA.debugLine="Private Page As Page";
self->__page = [B4IPage new];
 //BA.debugLineNum = 6;BA.debugLine="Private imgFondoImagenTop As ImageView";
self->__imgfondoimagentop = [B4IImageViewWrapper new];
 //BA.debugLineNum = 7;BA.debugLine="Private lblNameUserPost As Label";
self->__lblnameuserpost = [B4ILabelWrapper new];
 //BA.debugLineNum = 8;BA.debugLine="Private lblEmailUserPost As Label";
self->__lblemailuserpost = [B4ILabelWrapper new];
 //BA.debugLineNum = 9;BA.debugLine="Private lblPhoneUserPost As Label";
self->__lblphoneuserpost = [B4ILabelWrapper new];
 //BA.debugLineNum = 10;BA.debugLine="Private JHRListViewPosts As JHRListView";
self->__jhrlistviewposts = [b4i_jhrlistview new];
 //BA.debugLineNum = 11;BA.debugLine="Type dataPosts(titlePosts As String, bodyPost As";
;
 //BA.debugLineNum = 12;BA.debugLine="Private imgUserPosts As ImageView";
self->__imguserposts = [B4IImageViewWrapper new];
 //BA.debugLineNum = 13;BA.debugLine="Private lblTittlePost As Label";
self->__lbltittlepost = [B4ILabelWrapper new];
 //BA.debugLineNum = 14;BA.debugLine="Private lblBodyPosts As Label";
self->__lblbodyposts = [B4ILabelWrapper new];
 //BA.debugLineNum = 15;BA.debugLine="Private lblIDPosts As Label";
self->__lblidposts = [B4ILabelWrapper new];
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return @"";
}
- (NSString*)  _show{
B4IJSONParser* _parser = nil;
B4IList* _rootmap = nil;
B4IMap* _colrootmap = nil;
_dataposts* _data = nil;
B4IPanelWrapper* _p = nil;
 //BA.debugLineNum = 18;BA.debugLine="Sub Show";
 //BA.debugLineNum = 19;BA.debugLine="If Page.IsInitialized = False Then Page.Initializ";
if ([self->__page IsInitialized]==false) { 
[self->__page Initialize:self.bi :@"Page"];};
 //BA.debugLineNum = 20;BA.debugLine="Main.NavControl.ShowPage (Page)";
[self->__main->__navcontrol /*B4INavigationControllerWrapper**/  ShowPage:(UIViewController*)((self->__page).object)];
 //BA.debugLineNum = 21;BA.debugLine="Page.RootPanel.RemoveAllViews";
[[self->__page RootPanel] RemoveAllViews];
 //BA.debugLineNum = 22;BA.debugLine="Page.RootPanel.LoadLayout (\"postsUser\")";
[[self->__page RootPanel] LoadLayout:@"postsUser" :self.bi];
 //BA.debugLineNum = 23;BA.debugLine="lblNameUserPost.Text = Main.valueObject.As(dataUs";
[self->__lblnameuserpost setText:((_datauser*)(self->__main->__valueobject /*NSObject**/ ))->_nameUser /*NSString**/ ];
 //BA.debugLineNum = 24;BA.debugLine="lblEmailUserPost.Text = Main.valueObject.As(dataU";
[self->__lblemailuserpost setText:((_datauser*)(self->__main->__valueobject /*NSObject**/ ))->_emailUser /*NSString**/ ];
 //BA.debugLineNum = 25;BA.debugLine="lblPhoneUserPost.Text = Main.valueObject.As(dataU";
[self->__lblphoneuserpost setText:((_datauser*)(self->__main->__valueobject /*NSObject**/ ))->_phoneUser /*NSString**/ ];
 //BA.debugLineNum = 26;BA.debugLine="imgUserPosts.Bitmap = LoadBitmap(File.DirAssets,M";
[self->__imguserposts setBitmap:[self->___c LoadBitmap:[[self->___c File] DirAssets] :((_datauser*)(self->__main->__valueobject /*NSObject**/ ))->_imageFile /*NSString**/ ]];
 //BA.debugLineNum = 27;BA.debugLine="imgFondoImagenTop.Bitmap = LoadBitmap(File.DirAss";
[self->__imgfondoimagentop setBitmap:[self->___c LoadBitmap:[[self->___c File] DirAssets] :([@[@"pexels-photo-",[self->___c SmartStringFormatter:@"" :(NSObject*)(@([self->___c Rnd:(int) (1) :(int) (4)]))],@".jpeg"] componentsJoinedByString:@""])]];
 //BA.debugLineNum = 28;BA.debugLine="Dim parser As JSONParser";
_parser = [B4IJSONParser new];
 //BA.debugLineNum = 29;BA.debugLine="parser.Initialize(Main.stringPosts)";
[_parser Initialize:self->__main->__stringposts /*NSString**/ ];
 //BA.debugLineNum = 30;BA.debugLine="Dim rootMap As List = parser.NextArray";
_rootmap = [B4IList new];
_rootmap = [_parser NextArray];
 //BA.debugLineNum = 31;BA.debugLine="For Each colrootMap As Map In rootMap";
{
const id<B4IIterable> group13 = _rootmap;
const int groupLen13 = group13.Size
;int index13 = 0;
;
for (; index13 < groupLen13;index13++){
_colrootmap = (B4IMap*)([group13 Get:index13]);
 //BA.debugLineNum = 32;BA.debugLine="Dim data As dataPosts";
_data = [_dataposts new];
 //BA.debugLineNum = 33;BA.debugLine="data.Initialize";
[_data Initialize];
 //BA.debugLineNum = 34;BA.debugLine="data.titlePosts = colrootMap.Get(\"title\")";
_data->_titlePosts /*NSString**/  = [self.bi ObjectToString:[_colrootmap Get:(NSObject*)(@"title")]];
 //BA.debugLineNum = 35;BA.debugLine="data.bodyPost = colrootMap.Get(\"body\")";
_data->_bodyPost /*NSString**/  = [self.bi ObjectToString:[_colrootmap Get:(NSObject*)(@"body")]];
 //BA.debugLineNum = 36;BA.debugLine="data.userIdPosts = colrootMap.Get(\"id\")";
_data->_userIdPosts /*int*/  = [self.bi ObjectToNumber:[_colrootmap Get:(NSObject*)(@"id")]].intValue;
 //BA.debugLineNum = 37;BA.debugLine="Dim p As Panel = xui.CreatePanel(\"\")";
_p = [B4IPanelWrapper new];
_p = (B4IPanelWrapper*) [B4IObjectWrapper createWrapper:[B4IPanelWrapper new] object:(B4IPanelView*)(([self->__xui CreatePanel:self.bi :@""]).object)];
 //BA.debugLineNum = 38;BA.debugLine="p.SetLayoutAnimated(0,1, 0, 0, JHRListViewPosts.";
[_p SetLayoutAnimated:(int) (0) :(float) (1) :(float) (0) :(float) (0) :[[self->__jhrlistviewposts _asview] Width] :(float) (((int) (280)))];
 //BA.debugLineNum = 39;BA.debugLine="JHRListViewPosts.Add(p, data)";
[self->__jhrlistviewposts _add:(B4XViewWrapper*) [B4IObjectWrapper createWrapper:[B4XViewWrapper new] object:(NSObject*)((_p).object)] :(NSObject*)(_data)];
 }
};
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return @"";
}
@end
